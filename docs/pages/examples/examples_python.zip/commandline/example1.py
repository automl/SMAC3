"""
Blub
^^^^

This example doesn't do much, it just makes a simple plot
"""

print("jköase")
