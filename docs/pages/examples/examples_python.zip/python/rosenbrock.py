"""
Rosenbrock
^^^^^^^^^^

- Short description of the usecase
- What is covered in the example?
- Why is the facade chosen as it is?

"""

# your code here
